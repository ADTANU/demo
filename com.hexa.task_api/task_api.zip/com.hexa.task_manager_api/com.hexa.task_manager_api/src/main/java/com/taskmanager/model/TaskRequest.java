package com.taskmanager.model;

import java.time.LocalDate;

import com.taskmanager.model.Task.Priority;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class TaskRequest {
    private String title;
    private String description;
    private LocalDate dueDate;
    private Priority priority;
}