package com.hexa.com.hexa.task_manager_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
